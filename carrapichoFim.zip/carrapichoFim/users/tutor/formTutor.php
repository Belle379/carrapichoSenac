<!DOCTYPE html>
<html lang="pt-Br">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">



	<title> Cadastro dono</title>

</head>

<body>
	
	<h2> Cadastro Tutor </h2>
	<form action="./cadastrarTutor.php" method="POST">

		<h3> Dados Pessoias </h3>

		<label for="name">CPF</label>
		<input type="number" name="CPF_dono" id="CPF_dono" placeholder="000.000.000-00" required><br>

		<label for="name">Nome</label>
		<input type="text" name="nome_dono" id="nome_dono" placeholder="Digite seu nome" required><br>

		<label for="name">Nº de Telefone</label>
		<input type="number" name="fone_dono" id="fone_dono" placeholder="(99) 9 9999-9999" required><br>

		<label for="name">E-mail</label>
		<input type="text" name="email_dono" id="email_dono" placeholder="nickname@provedor.com" required><br>

		<label for="name">Senha</label>
		<input type="text" name="senha_dono" id="senha_dono" placeholder="Crie uma senha" required><br>

		<label for="name">Confirmar Senha</label>
		<input type="text" name="Csenha_dono" id="Csenha_dono" placeholder="Confirme a senha" required><br>
		<input type="submit" value="Próximo" name="Cadastrar">
      </form>

		</div>
	

		
		</div>
		</div>

		</div>
		</div>
		</div>

</body>

</html>